//
//  ViewController.swift
//  235475.MBialek
//
//  Created by Student11 on 19/05/2020.
//  Copyright © 2020 Student11. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var Cost: UITextField!
    
    @IBOutlet weak var Tip: UILabel!
    @IBOutlet weak var State_Switch_1: UISwitch!
    @IBOutlet weak var State_Switch_2: UISwitch!
    
    @IBAction func calculate(_ sender: UIButton) {
        var tip: Float = 0
        let cost: Float = (Cost!.text! as NSString).floatValue
        var additives: Float = 0.05
        if State_Switch_1.isOn {
            additives = additives+0.02
        }
        if State_Switch_2.isOn {
            additives = additives+0.02
        }
        tip = roundf(cost * additives * 100)/100
        Tip!.text = String(tip) + " zł"
    }
    @IBAction func clear_all(_ sender: UIButton) {
        Cost!.text = ""
        Tip!.text = "Kwota"
        State_Switch_1.setOn(false, animated: true)
        State_Switch_2.setOn(false, animated: true)
    }
}
