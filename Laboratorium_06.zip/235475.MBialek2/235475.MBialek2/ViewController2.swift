//
//  ViewController2.swift
//  235475.MBialek2
//
//  Created by Student11 on 02/06/2020.
//  Copyright © 2020 Student11. All rights reserved.
//

import UIKit

class ViewController2: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBOutlet weak var Tekst: UILabel!

    @IBOutlet weak var Temp: UITextField!
    @IBOutlet weak var Dalej: UIButton!
    var wiek = ""
    var temp = ""
    
    @IBAction func dalej(_ sender: Any) {
            
            if Temp!.text!.isEmpty || Temp!.text! == "Podaj temperature !!!" || Temp!.text! == "Podano złą wartość !"{
                Temp!.text! = "Podaj temperature !!!"
            }
            else{
                let temperatura: Float = (Temp!.text! as NSString).floatValue
                if temperatura > 35 && temperatura < 43{
                    temp = Temp!.text!
                    performSegue(withIdentifier: "TempToInfo", sender: self)
                }
                else{
                    Temp!.text! = "Podano złą wartość !"
                }
                
            }
    }
        override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        var temptoinfo = segue.destination as! ViewController3
        temptoinfo.wiek =  wiek
        temptoinfo.temp = temp
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
