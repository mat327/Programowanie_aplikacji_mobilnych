//
//  ViewController.swift
//  235475.MBialek2
//
//  Created by Student11 on 02/06/2020.
//  Copyright © 2020 Student11. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

   
    override func viewDidLoad() {
        super.viewDidLoad()
        print ("ViewController : view did load")
    }
    
    override func awakeFromNib() {
        print("VeiwController : awake from nib")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        print("ViewController : view will appear")
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        print("ViewController : view did appear")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        print("ViewController : view will disappear")
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        print("ViewController : view did disappear")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        print("ViewController : did receive memory warning")
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        print("ViewController : view will layout subviews")
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        print("ViewController : view did layout subviews")
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        print("ViewController : view will transition")
    }
    
    @IBOutlet weak var Dalej: UIButton!
    @IBOutlet weak var Wiek: UITextField!
    @IBOutlet var tekst: UIView!

         var wiek = ""
    @IBAction func dalej(_ sender: Any) {
        if Wiek!.text!.isEmpty || Wiek!.text! == "Podaj wiek !!!"{
            Wiek!.text! = "Podaj wiek !!!"
        }
        else{
            wiek = Wiek!.text!
            performSegue(withIdentifier: "AgeToTemp", sender: self)        }
        }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        var agetotemp = segue.destination as! ViewController2
        agetotemp.wiek =  wiek
    }
        
}

