//
//  ViewController3.swift
//  235475.MBialek2
//
//  Created by Student11 on 02/06/2020.
//  Copyright © 2020 Student11. All rights reserved.
//

import UIKit

class ViewController3: UIViewController {
    var wiek = ""
    var temp = ""
    
    @IBOutlet weak var Zalecenia: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let Wiek: Float = (wiek as NSString).floatValue
        let Temp: Float = (temp  as NSString).floatValue
        
        if Wiek < 40 && Temp < 38{
            Zalecenia!.text! = "Nie ma się czego obawiać."
        }
        
        if Wiek < 40 && Temp >= 38{
            Zalecenia!.text! = "Temperatura wysoka skonsultuj się z lekarzem."
        }
        
        if Wiek >= 40 && Temp < 38{
            Zalecenia!.text! = "Temperatura nie jest wysoka ale pamiętaj jesteś w grupie wysokiego ryzyka."
        }
        
        if Wiek >= 40 && Temp >= 38{
            Zalecenia!.text! = "Natychmiast skontaktuj się z lekarzem."
        }
        // Do any additional setup after loading the view.
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
